package com.example.ForDev

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
