abstract class FetchSecureCacheStorage {
  Future<String> fetchSecure(String key);
}