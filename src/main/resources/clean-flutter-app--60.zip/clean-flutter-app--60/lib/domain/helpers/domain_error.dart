enum DomainError {
  unexpected,
  invalidCredentials,
  emailInUse,
  accessDenied
}