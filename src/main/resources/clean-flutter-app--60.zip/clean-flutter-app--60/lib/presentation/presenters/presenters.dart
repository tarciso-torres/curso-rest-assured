export './getx_login_presenter.dart';
export './getx_signup_presenter.dart';
export './getx_splash_presenter.dart';
export './getx_surveys_presenter.dart';