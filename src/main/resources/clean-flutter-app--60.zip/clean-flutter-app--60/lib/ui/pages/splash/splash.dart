export 'splash_page.dart';
export 'splash_presenter.dart';