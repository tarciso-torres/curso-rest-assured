# Save Secure Cache

> ## Sucesso
1. ✅ Inserir dados no cache seguro

> ## Exceção - Erro ao inserir dados no cache seguro
1. ✅ Deve repassar a exceção para quem chamou essa classe