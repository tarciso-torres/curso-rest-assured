# Fetch Secure Cache

> ## Sucesso
1. ✅ Solicitar dados de uma chave do cache seguro
2. ✅ Retornar o valor armazenado para aquela chave

> ## Exceção - Erro ao carregar os dados do cache seguro
1. ✅ Deve repassar a exceção para quem chamou essa classe