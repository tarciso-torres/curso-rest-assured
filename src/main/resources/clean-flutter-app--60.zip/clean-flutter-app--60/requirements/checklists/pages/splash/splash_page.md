# Splash Page

> ## Regras
1. ✅ Mostrar loading ao iniciar a página
2. ✅ Chamar o carregar dados da conta atual
3. ✅ Navegar para a página correta ao final do carregamento