# SignUp Page

> ## Regras
1. ✅ Os campos devem começar sem exibir mensagem de erro
2. ✅ O botão de criar conta deve começar desabilitado
3. ✅ Após digitar algo em um campo, a mensagem de erro só deve sumir se o campo for válido
4. ✅ Validar email quando o usuário digitar no campo
5. ✅ Mostrar mensagem de erro se o email for inválido
6. ✅ Remover mensagem de erro se o email for válido
7. ✅ Validar senha quando o usuário digitar no campo
8. ✅ Mostrar mensagem de erro se a senha for inválida
9. ✅ Remover mensagem de erro se a senha for válida
10. ✅ Validar nome quando o usuário digitar no campo
11. ✅ Mostrar mensagem de erro se o nome for inválido
12. ✅ Remover mensagem de erro se o nome for válido
13. ✅ Validar confirmação de senha quando o usuário digitar no campo
14. ✅ Mostrar mensagem de erro se a confirmação de senha for inválida
15. ✅ Remover mensagem de erro se a confirmação de senha for válida
16. ✅ Habilitar o botão de criar conta se todos os campos forem válidos
17. ✅ Desabilitar o botão de criar conta se algum campo for inválido
18. ✅ Exibir loading no início da ação de criar conta
19. ✅ Chamar o método de criar conta
20. ✅ Exibir mensagem de erro caso a criação de conta falhe
21. ✅ Esconder loading no fim da ação de criar conta
22. ✅ Chamar o método de Login ao clicar no link