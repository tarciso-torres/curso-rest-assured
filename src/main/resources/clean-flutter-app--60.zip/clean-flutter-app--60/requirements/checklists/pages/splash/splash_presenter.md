# Splash Presenter

> ## Regras
1. ✅ Chamar o LoadCurrentAccount
2. ✅ Levar o usuário pra tela de Enquetes se tiver dados no cache
3. ✅ Levar o usuário pra tela de Login se não tiver dados no cache
4. ✅ Levar o usuário pra tela de Login se der erro ao carregar dados do cache