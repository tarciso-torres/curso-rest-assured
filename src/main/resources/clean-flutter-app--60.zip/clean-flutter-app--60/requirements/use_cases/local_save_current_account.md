# Local Save Current Account Use Case

> ## Caso de sucesso
1. ✅ Sistema grava o token de acesso do usuário no Cache de forma segura

> ## Exceção - Falha ao gravar no cache
1. ✅ Sistema retorna uma mensagem de erro inesperado